import React from 'react';
import Navbar from '../../components/Navbar/Navbar';
import CarCard from '../../components/CarCard/CarCard';
import './Recommendations.css';
import { useNavigate } from 'react-router-dom';

const Recommendations = () => {
  const recommendedCars = [
    { id: 1, name: 'Tesla Model S', image: 'https://cdn.drivingexperience.com/cdn-cgi/image/format=auto,fit=contain/cars/tesla-model-s.png' },
    { id: 2, name: 'Toyota Camry', image: 'https://images.dealer.com/ddc/vehicles/2025/Toyota/Camry/Sedan/trim_LE_4b85cc/color/Ocean%20Gem-795-5%2C96%2C114-640-en_US.jpg?impolicy=downsize_bkpt&imdensity=1&w=520' },
    { id: 3, name: 'Ford Mustang', image: 'https://crdms.images.consumerreports.org/c_lfill,w_470,q_auto,f_auto/prod/cars/cr/car-versions/25751-2024-ford-mustang-gt' },
    { id: 4, name: 'Tesla Model S', image: 'https://cdn.drivingexperience.com/cdn-cgi/image/format=auto,fit=contain/cars/tesla-model-s.png' },
    { id: 5, name: 'Toyota Camry', image: 'https://images.dealer.com/ddc/vehicles/2025/Toyota/Camry/Sedan/trim_LE_4b85cc/color/Ocean%20Gem-795-5%2C96%2C114-640-en_US.jpg?impolicy=downsize_bkpt&imdensity=1&w=520' },
    { id: 6, name: 'Ford Mustang', image: 'https://crdms.images.consumerreports.org/c_lfill,w_470,q_auto,f_auto/prod/cars/cr/car-versions/25751-2024-ford-mustang-gt' },
  ];

  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Update Preferences clicked');
    navigate('/preferences');
    // Send preferences to the backend for processing
  };

  return (
    <div className="recommendations">
      <h1>Your Recommendations</h1>
      <div className="car-list">
        {recommendedCars.map((car) => (
          <CarCard key={car.id} car={car} />
        ))}
        <div className="button-container">
          <button className="updatepref" onClick={handleSubmit}>Update Preferences</button>
        </div>
      </div>
    </div>
  );
};

export default Recommendations;