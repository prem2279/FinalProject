import React, { useState } from 'react';
import Navbar from '../../components/Navbar/Navbar';
import './Profile.css';

const Profile = () => {
  const [user, setUser] = useState({
    name: 'John Doe',
    email: 'john.doe@example.com',
    preferences: {
      bodyStyle: 'SUV',
      engineType: 'Hybrid',
      exhaust: 'Dual',
      tyres: 'All-Terrain',
      fuelType: 'Hybrid',
      transmission: 'Automatic',
      seatingCapacity: '5',
    },
  });

  const handleUpdate = (e) => {
    e.preventDefault();
    console.log('Profile updated:', user);
    // Send updated profile data to the backend
  };

  return (
    <div className="profile">
      <Navbar />
      <h1>Your Profile</h1>
      <form className="profile-form" onSubmit={handleUpdate}>
        <label>
          Name:
          <input
            type="text"
            value={user.name}
            onChange={(e) => setUser({ ...user, name: e.target.value })}
          />
        </label>
        <label>
          Email:
          <input
            type="email"
            value={user.email}
            onChange={(e) => setUser({ ...user, email: e.target.value })}
          />
        </label>
        <h2>Preferences</h2>
        <div className="preferences">
          <p><strong>Body Style:</strong> {user.preferences.bodyStyle}</p>
          <p><strong>Engine Type:</strong> {user.preferences.engineType}</p>
          <p><strong>Exhaust:</strong> {user.preferences.exhaust}</p>
          <p><strong>Tyres:</strong> {user.preferences.tyres}</p>
          <p><strong>Fuel Type:</strong> {user.preferences.fuelType}</p>
          <p><strong>Transmission:</strong> {user.preferences.transmission}</p>
          <p><strong>Seating Capacity:</strong> {user.preferences.seatingCapacity}</p>
        </div>
        <button type="submit">Update Profile</button>
      </form>
    </div>
  );
};

export default Profile;