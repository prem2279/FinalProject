import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom'; // Add useNavigate
import Navbar from '../../components/Navbar/Navbar';
import './CarDetails.css';

const CarDetails = () => {
  const { id } = useParams(); // Get car ID from URL
  const navigate = useNavigate(); // Hook for navigation
  const [car, setCar] = useState(null);

  // Mock car data (replace with API call)
  const cars = [
    { id: 1, name: 'Tesla Model S', image: 'https://cdn.drivingexperience.com/cdn-cgi/image/format=auto,fit=contain/cars/tesla-model-s.png', description: 'The Tesla Model S is a fully electric luxury sedan with cutting-edge technology and impressive performance.', bodyStyle: 'Sedan', engineType: 'Electric', exhaust: 'Single', tyres: 'Performance', fuelType: 'Electric', transmission: 'Automatic', seatingCapacity: '5' },
    { id: 2, name: 'Toyota Camry', image: 'https://images.dealer.com/ddc/vehicles/2025/Toyota/Camry/Sedan/trim_LE_4b85cc/color/Ocean%20Gem-795-5%2C96%2C114-640-en_US.jpg?impolicy=downsize_bkpt&imdensity=1&w=520', description: 'The Toyota Camry is a reliable and fuel-efficient midsize sedan.', bodyStyle: 'Sedan', engineType: 'Hybrid', exhaust: 'Single', tyres: 'Standard', fuelType: 'Hybrid', transmission: 'Automatic', seatingCapacity: '5' },
    { id: 3, name: 'Ford Mustang', image: 'https://crdms.images.consumerreports.org/c_lfill,w_470,q_auto,f_auto/prod/cars/cr/car-versions/25751-2024-ford-mustang-gt', description: 'The Ford Mustang is an iconic American muscle car with powerful performance.', bodyStyle: 'Coupe', engineType: 'Gasoline', exhaust: 'Dual', tyres: 'Performance', fuelType: 'Gasoline', transmission: 'Manual', seatingCapacity: '4' },
  ];

  useEffect(() => {
    // Fetch car details based on ID
    const selectedCar = cars.find((car) => car.id === parseInt(id));
    setCar(selectedCar);
  }, [id]);

  const handleBack = () => {
    navigate('/recommendations'); // Navigate back to Recommendations page
  };

  if (!car) {
    return <div>Loading...</div>; // Handle case where car is not found
  }

  return (
    <div className="car-details">
      <div className="car-content">
        <img src={car.image} alt={car.name} />
        <div className="car-info">
          <h1>{car.name}</h1>
          <p>{car.description}</p>
          <div className="car-specs">
            <p><strong>Body Style:</strong> {car.bodyStyle}</p>
            <p><strong>Engine Type:</strong> {car.engineType}</p>
            <p><strong>Exhaust:</strong> {car.exhaust}</p>
            <p><strong>Tyres:</strong> {car.tyres}</p>
            <p><strong>Fuel Type:</strong> {car.fuelType}</p>
            <p><strong>Transmission:</strong> {car.transmission}</p>
            <p><strong>Seating Capacity:</strong> {car.seatingCapacity}</p>
          </div>
          <button onClick={handleBack}>Back to Recommendations</button>
          <button onClick={handleBack}>Add to Favorites</button>
        </div>
      </div>
    </div>
  );
};

export default CarDetails;