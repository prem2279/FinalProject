import React, { useState } from 'react';
import Navbar from '../../components/Navbar/Navbar';
import PreferenceForm from '../../components/PreferenceForm/PreferenceForm';
import './Preferences.css';
import { useNavigate } from 'react-router-dom';

const Preferences = () => {
  const [preferences, setPreferences] = useState({
    bodyStyle: '',
    engineType: '',
    exhaust: '',
    tyres: '',
    fuelType: '',
    transmission: '',
    seatingCapacity: '',
  });
  const navigate = useNavigate();
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Preferences submitted:', preferences);
    navigate('/recommendations');
  };

  return (
    <div className="preferences">
      <h1>Set Your Preferences</h1>
      <PreferenceForm
        preferences={preferences}
        setPreferences={setPreferences}
        onSubmit={handleSubmit}
      />
    </div>
  );
};

export default Preferences;