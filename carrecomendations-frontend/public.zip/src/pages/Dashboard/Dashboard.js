import React from 'react';
import Navbar from '../../components/Navbar/Navbar';
import './Dashboard.css';
import { BarChart, LineChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const Dashboard = () => {
  const user = {
    name: 'Team Straw Hats',
    email: 'team7@albany.edu',
    statistics: {
      carsViewed: 12,
      recommendationsGenerated: 8,
      favoritesAdded: 3,
    },
    preferences: {
      bodyStyle: 'SUV',
      engineType: 'Hybrid',
      fuelType: 'Electric',
      transmission: 'Automatic',
      seatingCapacity: '5',
    },
    recentActivity: [
      { id: 1, name: 'Tesla Model S', date: '2023-10-15' },
      { id: 2, name: 'Toyota Camry Hybrid', date: '2023-10-14' },
      { id: 3, name: 'Ford Mustang', date: '2023-10-13' },
    ],
    favorites: [
      { id: 1, name: 'Tesla Model S', image: 'https://cdn.drivingexperience.com/cdn-cgi/image/format=auto,fit=contain/cars/tesla-model-s.png' },
      { id: 2, name: 'Toyota Camry Hybrid', image: 'https://images.dealer.com/ddc/vehicles/2025/Toyota/Camry/Sedan/trim_LE_4b85cc/color/Ocean%20Gem-795-5%2C96%2C114-640-en_US.jpg' },
    ],
    statistics: {
      carsViewed: 12,
      recommendationsGenerated: 8,
      favoritesAdded: 3,
    },
    notifications: [
      { id: 1, message: 'New recommendation: Tesla Model Y', date: '2023-10-15' },
      { id: 2, message: 'Your favorite car is now available for a test drive', date: '2023-10-14' },
    ],
    upcomingEvents: [
      { id: 1, name: 'Electric Car Expo', date: '2023-11-05', location: 'New York' },
      { id: 2, name: 'Hybrid Car Test Drive', date: '2023-11-10', location: 'Los Angeles' },
    ],
  };

   // Data for the charts
   const chartData = [
    { name: 'Cars Viewed', value: user.statistics.carsViewed },
    { name: 'Recommendations', value: user.statistics.recommendationsGenerated },
    { name: 'Favorites', value: user.statistics.favoritesAdded },
  ];

  return (
    <div className="dashboard">
      <div className="dashboard-container">
        <h1>Welcome, {user.name}!</h1>
        <div className="dashboard-content">
          {/* User Profile Summary */}
          <div className="profile-summary">
            <h2>Your Profile</h2>
            <p><strong>Name:</strong> {user.name}</p>
            <p><strong>Email:</strong> {user.email}</p>
          </div>

          {/* Preferences Summary */}
          <div className="preferences-summary">
            <h2>Your Preferences</h2>
            <p><strong>Body Style:</strong> {user.preferences.bodyStyle}</p>
            <p><strong>Engine Type:</strong> {user.preferences.engineType}</p>
            <p><strong>Fuel Type:</strong> {user.preferences.fuelType}</p>
            <p><strong>Transmission:</strong> {user.preferences.transmission}</p>
            <p><strong>Seating Capacity:</strong> {user.preferences.seatingCapacity}</p>
          </div>

          {/* Quick Actions */}
          <div className="quick-actions">
            <h2>Quick Actions</h2>
            <button className="action-btn">View Recommendations</button>
            <button className="action-btn">Edit Preferences</button>
            <button className="action-btn">Update Profile</button>
          </div>

          {/* Statistics */}
          <div className='statistics'>
          <h2>Statistics</h2>
          <div className="chart-container">
              
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="value" fill="#f39c12" />
                </BarChart>
              </ResponsiveContainer>
            </div>
            </div>
            

          {/* Favorites Section */}
          <div className="favorites">
            <h2>Your Favorites</h2>
            <div className="favorites-grid">
              {user.favorites.map((car) => (
                <div key={car.id} className="favorite-item">
                  <img src={car.image} alt={car.name} />
                  <p>{car.name}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Activity */}
          <div className="recent-activity">
            <h2>Recent Activity</h2>
            <ul>
              {user.recentActivity.map((activity) => (
                <li key={activity.id}>
                  <span className="activity-name">{activity.name}</span>
                  <span className="activity-date">{activity.date}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Notifications */}
          {/* <div className="notifications">
            <h2>Notifications</h2>
            <ul>
              {user.notifications.map((notification) => (
                <li key={notification.id}>
                  <span className="notification-message">{notification.message}</span>
                  <span className="notification-date">{notification.date}</span>
                </li>
              ))}
            </ul>
          </div> */}

          {/* Upcoming Events */}
          {/* <div className="upcoming-events">
            <h2>Upcoming Events</h2>
            <ul>
              {user.upcomingEvents.map((event) => (
                <li key={event.id}>
                  <span className="event-name">{event.name}</span>
                  <span className="event-date">{event.date}</span>
                  <span className="event-location">{event.location}</span>
                </li>
              ))}
            </ul>
          </div> */}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;