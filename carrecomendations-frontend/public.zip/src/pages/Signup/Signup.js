import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../../components/Navbar/Navbar';
import PreferenceForm from '../../components/PreferenceForm/PreferenceForm'; // Import the PreferenceForm component
import './Signup.css';

const Signup = () => {
  const [userData, setUserData] = useState({
    name: '',
    email: '',
    password: '',
  });

  const [preferences, setPreferences] = useState({
    bodyStyle: [],
    engineType: [],
    exhaust: [],
    tyres: [],
    fuelType: [],
    transmission: [],
    seatingCapacity: [],
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const user = { ...userData, preferences };
    console.log('User data:', user);
    // Send user data to the backend for registration
  };

  return (
    <div className="signup">
      <Navbar />
      <div className="signup-container">
        <h1>Sign Up</h1>
        <form onSubmit={handleSubmit}>
          {/* User Details Section */}
          <h2>User Details</h2>
          <label>
            Name:
            <input
              type="text"
              value={userData.name}
              onChange={(e) => setUserData({ ...userData, name: e.target.value })}
              required
            />
          </label>
          <label>
            Email:
            <input
              type="email"
              value={userData.email}
              onChange={(e) => setUserData({ ...userData, email: e.target.value })}
              required
            />
          </label>
          <label>
            Password:
            <input
              type="password"
              value={userData.password}
              onChange={(e) => setUserData({ ...userData, password: e.target.value })}
              required
            />
          </label>

          {/* Car Preferences Section */}
          <h2>Car Preferences</h2>
          <PreferenceForm
            preferences={preferences}
            setPreferences={setPreferences}
            onSubmit={handleSubmit}
          />

          {/* Submit Button */}
          <button type="submit">Sign Up</button>
        </form>
        <p>
          Already have an account? <Link to="/login">Login</Link>
        </p>
      </div>
    </div>
  );
};

export default Signup;