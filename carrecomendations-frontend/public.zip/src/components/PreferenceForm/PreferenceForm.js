import React from 'react';
import './PreferenceForm.css';

const PreferenceForm = ({ preferences, setPreferences, onSubmit }) => {
  const handleSelection = (category, value) => {
    const currentSelection = preferences[category] || [];
    if (currentSelection.includes(value)) {
      setPreferences({
        ...preferences,
        [category]: currentSelection.filter((item) => item !== value), // Remove if selected again
      });
    } else {
      setPreferences({
        ...preferences,
        [category]: [...currentSelection, value], // Allow multiple selections
      });
    }
  };

  const categories = {
    bodyStyle: ['sedan', 'suv', 'coupe'],
    exhaust: ['single', 'dual'],
    // tyres: ['all-terrain', 'performance', 'standard'],
    // fuelType: ['petrol', 'diesel', 'electric', 'hybrid'],
    // transmission: ['manual', 'automatic', 'CVT'],
    // seatingCapacity: ['2', '5', '7'],
  };

  const imageUrls = {
    // sedan: 'https://stimg.cardekho.com/images/carexteriorimages/930x620/Maruti/Dzire/11387/1731318279714/front-left-side-47.jpg',
    // suv: 'https://www.theglobeandmail.com/resizer/HQ2Wjd5EezIQT450Ixm2RloVeuU=/arc-anglerfish-tgam-prod-tgam/public/BOWTQI77NVHQNL5HPPT2DZGP5E.JPG',
    // coupe: 'https://images.fitmentindustries.com/web-compressed/332125-1-2013-genesis-coupe-hyundai-isr-coilovers-square-g8-gunmetal.jpg',
    // electric: 'https://u4d2z7k9.rocketcdn.me/wp-content/uploads/2022/05/Untitled-1024-%C3%97-768px-6.jpg',
    // hybrid: 'https://www.tycorun.com/cdn/shop/articles/1What_are_series_hybrid_vehicles_and_parallel_hybrid_vehicles_493x.jpg?v=1642241805',
    // diesel: 'https://cdn.images.express.co.uk/img/dynamic/24/590x/secondary/diesel-cars-1539903.jpg?r=1538983206421',
    // single: 'https://www.sp1-r.com/cdn/shop/products/46C6B083-720F-453C-B285-30E82ACCA5A0.jpg?v=1663480191&width=1946',
    // dual: 'https://www.aeroflowdynamics.com/cdn/shop/files/Untitleddesign_35_148895b0-8611-4365-8eda-b78b028733fc_grande.png?v=1718048985',
    // 'all-terrain': 'https://cncwheels.com.au/wp-content/uploads/2021/01/Maxxis_RAZR_AT811_Best_4x4_Tyre_.jpg',
    // performance: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQdxXY7ipCalX-EWdDTcPagtFgQQpP0PFINfA&s',
    // 'standard': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQX4m__CqwtX_DCp45_rueBMuAK_95Ip07g1A&s',
    // petrol: 'https://media.istockphoto.com/id/155350081/photo/at-the-gas-station.jpg?s=612x612&w=0&k=20&c=p0Mpur345bkeQ-32AcwnSbaCCr2B2HUzqZDIH_9oeWY=',
    // manual: 'https://www.usnews.com/cmsmedia/c7/7d/d55202084671b55f416ed69d8d82/15-2023-toyota-supra-gear-shift-jmv.JPG',
    // automatic: 'https://previews.123rf.com/images/norgal/norgal1602/norgal160200136/53285616-a-floor-selection-lever-of-car-with-automatic-transmission-gear-shift.jpg',
    // CVT: 'https://blog.way.com/wp-content/uploads/2024/04/AdobeStock_210039886-1-scaled.jpeg',
    // '2': 'https://www.beneoshop.com/pub/media/catalog/product/cache/3a08eb3d23ebc4db255aaaccf2e5c3fe/d/s/dsc_5548.jpg',
    // '5': 'https://www.terryvillechevy.com/static/dealer-24224/Aronson/Equinox/2024/24Chevy-Equinox-InteriorSeatingCutawaySideView-5x3.jpg',
    // '7': 'https://s3.amazonaws.com/images.gearjunkie.com/uploads/2022/09/2022-Grand-Wagoneer-Interior.jpg',
  };

  return (
    <form className="preference-form" onSubmit={onSubmit}>
      {Object.entries(categories).map(([category, options]) => (
        <div key={category}>
          <label>{category.replace(/([A-Z])/g, ' $1').trim()}</label>
          <div className="option-group">
            {options.map((type) => {
              const imageUrl = imageUrls[type] || `default-images/${category}-type.jpg`;
              return (
                <div
                  key={type}
                  className={`option ${preferences[category]?.includes(type) ? 'selected' : ''}`}
                  onClick={() => handleSelection(category, type)}
                >
                  {/* <img src={imageUrl} alt={type} /> */}
                  <img src='https://images.pexels.com/photos/1335077/pexels-photo-1335077.jpeg?cs=srgb&dl=pexels-mikebirdy-1335077.jpg&fm=jpg'></img>
                  <p>{type.charAt(0).toUpperCase() + type.slice(1)}</p>
                </div>
              );
            })}
          </div>
        </div>
      ))}

      {/* Save Preferences Button */}
      <button type="submit">Show Recommendations</button>
    </form>
  );
};

export default PreferenceForm;