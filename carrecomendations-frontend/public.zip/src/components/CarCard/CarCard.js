import React from 'react';
import { useNavigate } from 'react-router-dom';
import './CarCard.css';

const CarCard = ({ car }) => {
  const navigate = useNavigate();

  const handleViewDetails = () => {
    navigate(`/car/${car.id}`); // Navigate to CarDetails page with car.id
  };

  return (
    <div className="car-card">
      <img src={car.image} alt={car.name} />
      <h3>{car.name}</h3>
      <button onClick={handleViewDetails}>View Details</button>
    </div>
  );
};

export default CarCard;