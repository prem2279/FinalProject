import React from 'react';
import './Footer.css';

const Footer = () => {
  return (
    <footer className="footer">
      <p>&copy; Developed by Team Strawhats (Team N)</p>
    </footer>
  );
};

export default Footer;